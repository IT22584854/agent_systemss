# Highly skilled clinicians back by cutting edge technology
# Digital transformation at hospital doorstep
# Giving children the care they deserve.
# Dedicated Multi Professional Healthcare Team
# Progressive care with compassion
# Highly skilled clinicians back by cutting edge technology
# Digital transformation at hospital doorstep
# Giving children the care they deserve.
# Dedicated Multi Professional Healthcare Team
# Progressive care with compassion
# Highly skilled clinicians back by cutting edge technology
Welcome to
Ministry of Health Sri Lanka
The Ministry of Health is the government institution charged with governing the entire Sri Lankan health system. We play a critical role in protecting the general public's health and make sure that all organizations and institutions that provide products and services to the public adhere to the safety regulations. We ensure that all people and communities in Sri Lanka receive the quality health services they need, without financial hardship.
Our Vision
‘’A healthier nation that contributes to its economic, social, mental and spiritual development.‘’
###### Secretary / Ministry of Health and Mass Media
#### Dr. Anil Jasinghe
###### Director General of Health Services
#### Dr. Asela Gunawardena
###### Minister of Health and Mass Media
#### Dr. Nalinda Jayatissa
###### Deputy Minister of Health and Mass Media
#### Dr. Hansaka Wijemuni
###### Secretary / Ministry of Health and Mass Media
#### Dr. Anil Jasinghe
###### Director General of Health Services
#### Dr. Asela Gunawardena
###### Minister of Health and Mass Media
#### Dr. Nalinda Jayatissa
###### Deputy Minister of Health and Mass Media
#### Dr. Hansaka Wijemuni
Our Mission
‘’To contribute to the social and economic development of Sri Lanka by achieving the highest attainable health status through promotive, preventive, curative and rehabilitative services of high quality made available and accessible to people of Sri Lanka.‘’
[ Read More ](https://www.health.gov.lk/about-us#vision)
### Health Highlights
##### [Donate Now – Sri Lanka Needs You ](https://www.health.gov.lk/healthallert-home/donate-now-sri-lanka-needs-you/)
##### [COVID-19 Smart Vaccine Certificate ](https://www.health.gov.lk/healthallert-home/health-alert-title/)
##### [Colombo Declaration on ‘Healthy ageing through strengthened primary health care’ ](https://www.health.gov.lk/healthallert-home/colombo-declaration-on-healthy-ageing-through-strengthened-primary-health-care/)
##### [Leading with Compassion and Care… Recent Health Sector Success Stories from Sri Lanka ](https://www.health.gov.lk/healthallert-home/leading-with-compassion-and-care-recent-health-sector-success-stories-from-sri-lanka/)
##### [National Health Performance Dashboard ](https://www.health.gov.lk/healthallert-home/national-health-performance-dashboard/)
##### [Drug Availability – SWASTHA ](https://www.health.gov.lk/healthallert-home/health-alert-title-2/)
##### [Donate Now – Sri Lanka Needs You ](https://www.health.gov.lk/healthallert-home/donate-now-sri-lanka-needs-you/)
##### [COVID-19 Smart Vaccine Certificate ](https://www.health.gov.lk/healthallert-home/health-alert-title/)
##### [Colombo Declaration on ‘Healthy ageing through strengthened primary health care’ ](https://www.health.gov.lk/healthallert-home/colombo-declaration-on-healthy-ageing-through-strengthened-primary-health-care/)
##### [Leading with Compassion and Care… Recent Health Sector Success Stories from Sri Lanka ](https://www.health.gov.lk/healthallert-home/leading-with-compassion-and-care-recent-health-sector-success-stories-from-sri-lanka/)
### Featured News
7th Apr 2025
##### A comprehensive plan to digitally transform healthcare
[READ MORE ](https://www.health.gov.lk/news/a-comprehensive-plan-to-digitally-transform-healthcare/)
2nd Apr 2025
##### The Ministry of Health is fully focused on urgent measures that can be taken to control cancer in the country…
[READ MORE ](https://www.health.gov.lk/news/the-ministry-of-health-is-fully-focused-on-urgent-measures-that-can-be-taken-to-control-cancer-in-the-country/)
[ 16th Dec 2025 Mr. IWASE KIICHIRO, the head of the disaster management expert team that arrived in Sri Lanka from Japan, emphasizes that the program to provide emergency health services to the people affected by disasters in Sri Lanka was very successful. ](https://www.health.gov.lk/news/mr-iwase-kiichiro-the-head-of-the-disaster-management-expert-team-that-arrived-in-sri-lanka-from-japan-emphasizes-that-the-program-to-provide-emergency-health-services-to-the-people-affected-by-dis/)
12th Dec 2025
##### The International Conference on Emergency Ultrasound (ResUSS 2025) will commence in Kalutara under the patronage of the Minister of Health and Mass Media, Dr. Nalinda Jayatissa…
[READ MORE ](https://www.health.gov.lk/news/the-international-conference-on-emergency-ultrasound-resuss-2025-will-commence-in-kalutara-under-the-patronage-of-the-minister-of-health-and-mass-media-dr-nalinda-jayatissa/)
31st Oct 2025
##### Appointment letters will be issued to recruit 700 nursing graduates for the Reintegration and Integration Training Course after 04 years.
[READ MORE ](https://www.health.gov.lk/news/appointment-letters-will-be-issued-to-recruit-700-nursing-graduates-for-the-reintegration-and-integration-training-course-after-04-years/)
14th Oct 2025
##### Today is the second day of the 78th Regional Conference of the World Health Organization (WHO) for South and Southeast Asia.
[READ MORE ](https://www.health.gov.lk/news/today-is-the-second-day-of-the-78th-regional-conference-of-the-world-health-organization-who-for-south-and-southeast-asia/)
13th Oct 2025
##### The 78th Regional Conference of the World Health Organization (WHO) for South and Southeast Asian countries is being held.
[READ MORE ](https://www.health.gov.lk/news/the-78th-regional-conference-of-the-world-health-organization-who-for-south-and-southeast-asian-countries-is-being-held/)
13th Oct 2025
##### How can we strengthen pediatric anesthesia and surgery care across South-East Asia?
[READ MORE ](https://www.health.gov.lk/news/how-can-we-strengthen-pediatric-anesthesia-and-surgery-care-across-south-east-asia/)
12th Oct 2025
##### WHO’s 78th South-East Asia Regional Committee session begins tomorrow in Colombo
[READ MORE ](https://www.health.gov.lk/news/whos-78th-south-east-asia-regional-committee-session-begins-tomorrow-in-colombo/)
3rd Oct 2025
##### The fourth center of the pilot project to establish “Health and Wellness Centers” in the country has been opened to the public in Paulgollawatta, Kandy.
[READ MORE ](https://www.health.gov.lk/news/the-fourth-center-of-the-pilot-project-to-establish-health-and-wellness-centers-in-the-country-has-been-opened-to-the-public-in-paulgollawatta-kandy/)
25th Sep 2025
##### The 10th World Ayurveda Day is being celebrated with pride in Colombo.
[READ MORE ](https://www.health.gov.lk/news/the-10th-world-ayurveda-day-is-being-celebrated-with-pride-in-colombo/)
11th Sep 2025
##### The Japanese government’s continued support for the development of the Sri Lanka National Hospital…
[READ MORE ](https://www.health.gov.lk/news/the-japanese-governments-continued-support-for-the-development-of-the-sri-lanka-national-hospital/)
10th Sep 2025
##### The first program of the “Arogya” Mobile Health Clinic Program, which is being conducted for the well-being of government institution staff and their family members, is being conducted in Ja-Ela, focusing on the Gampaha District, for Sri Lanka Police officers.
[READ MORE ](https://www.health.gov.lk/news/the-first-program-of-the-arogya-mobile-health-clinic-program-which-is-being-conducted-for-the-well-being-of-government-institution-staff-and-their-family-members-is-being-conducted-in-ja-ela-fo/)
10th Sep 2025
##### India to fund emergency unit and equipment at Mannar District General Hospital
[READ MORE ](https://www.health.gov.lk/news/india-to-fund-emergency-unit-and-equipment-at-mannar-district-general-hospital/)
9th Sep 2025
##### The Minister of Health and Mass Media’s attention to the current health services in the Trincomalee district of the Eastern Province.
[READ MORE ](https://www.health.gov.lk/news/he-minister-of-health-and-mass-medias-attention-to-the-current-health-services-in-the-trincomalee-district-of-the-eastern-province/)
6th Sep 2025
##### The state-of-the-art infectious waste incinerator installed at the Trincomalee District General Hospital will be opened to the public. State-of-the-art infectious waste incinerators for 15 government hospitals…
[READ MORE ](https://www.health.gov.lk/news/the-state-of-the-art-infectious-waste-incinerator-installed-at-the-trincomalee-district-general-hospital-will-be-opened-to-the-public-state-of-the-art-infectious-waste-incinerators-for-15-government/)
3rd Sep 2025
##### Minister of Health and Mass Media inspects Kotelawala Defence University Hospital. A special discussion on the current status, future vision and objectives of the hospital.
[READ MORE ](https://www.health.gov.lk/news/minister-of-health-and-mass-media-inspects-kotelawala-defence-university-hospital-a-special-discussion-on-the-current-status-future-vision-and-objectives-of-the-hospital/)
2nd Sep 2025
##### A meeting between the Minister of Health and Mass Media and the Indonesian Ambassador to Sri Lanka.
[READ MORE ](https://www.health.gov.lk/news/a-meeting-between-the-minister-of-health-and-mass-media-and-the-indonesian-ambassador-to-sri-lanka/)
2nd Sep 2025
##### The Arogya Mobile Health Clinic organized by the Ministry of Health and Mass Media was held throughout the day yesterday (30) at the Kelinkanda Kosgulana Junior College in Palinda.
[READ MORE ](https://www.health.gov.lk/news/the-arogya-mobile-health-clinic-organized-by-the-ministry-of-health-and-mass-media-was-held-throughout-the-day-yesterday-30-at-the-kelinkanda-kosgulana-junior-college-in-palinda/)
30th Aug 2025
##### Plans are underway to provide a state-of-the-art linear accelerator machine to the cancer treatment unit at the Karapitiya National Hospital in Galle…
[READ MORE ](https://www.health.gov.lk/news/plans-are-underway-to-provide-a-state-of-the-art-linear-accelerator-machine-to-the-cancer-treatment-unit-at-the-karapitiya-national-hospital-in-galle/)
28th Aug 2025
##### The technical report on the 2025 National Immunization Conference is handed over to the Minister of Health and Mass Media.
[READ MORE ](https://www.health.gov.lk/news/the-technical-report-on-the-2025-national-immunization-conference-is-handed-over-to-the-minister-of-health-and-mass-media/)
13th Aug 2025
##### A meeting between the Minister of Health and Mass Media and the Finnish Ambassador.
[READ MORE ](https://www.health.gov.lk/news/a-meeting-between-the-minister-of-health-and-mass-media-and-the-finnish-ambassador/)
8th Aug 2025
##### The report analyzing “Sri Lanka’s Policy on Health Service Delivery for Universal Health Coverage” and “Guidelines for Mainstreaming Gender in Health Policies” is released.
[READ MORE ](https://www.health.gov.lk/news/the-report-analyzing-sri-lankas-policy-on-health-service-delivery-for-universal-health-coverage-and-guidelines-for-mainstreaming-gender-in-health-policies/)
4th Aug 2025
##### Intensive care medicine is a national priority…
[READ MORE ](https://www.health.gov.lk/news/intensive-care-medicine-is-a-national-priority/)
21st Jul 2025
##### Polonnaruwa National Vortex Specialist Hospital to be inspected by the Minister of Health and Mass Media.
[READ MORE ](https://www.health.gov.lk/news/polonnaruwa-national-vortex-specialist-hospital-to-be-inspected-by-the-minister-of-health-and-mass-media/)
7th Jul 2025
##### Quality, delicious food for inpatients in government hospitals. A special plate reserved for the patient. The pilot project will be launched at Apeksha Hospital, Maharagama…
[READ MORE ](https://www.health.gov.lk/news/quality-delicious-food-for-inpatients-in-government-hospitals-a-special-plate-reserved-for-the-patient-the-pilot-project-will-be-launched-at-apeksha-hospital-maharagama/)
4th Jul 2025
##### A five-storey children’s ward complex worth Rs. 600 million will be built for the Maharagama Apeksha Hospital.
[READ MORE ](https://www.health.gov.lk/news/a-five-storey-childrens-ward-complex-worth-rs-600-million-will-be-built-for-the-maharagama-apeksha-hospital/)
17th Jun 2025
##### Primary Health Care Units and Health Centers in the Southern Province are under the supervision of the Minister of Health and Mass Media.
[READ MORE ](https://www.health.gov.lk/news/primary-health-care-units-and-health-centers-in-the-southern-province-are-under-the-supervision-of-the-minister-of-health-and-mass-media/)
31st May 2025
##### A meeting between the Russian Ambassador to Sri Lanka and the Minister of Health and Mass Media.
[READ MORE ](https://www.health.gov.lk/news/a-meeting-between-the-russian-ambassador-to-sri-lanka-and-the-minister-of-health-and-mass-media/)
23rd May 2025
##### A meeting between the Minister of Health and Mass Media and the Director-General of the World Health Organization in Geneva, Switzerland
[READ MORE ](https://www.health.gov.lk/news/a-meeting-between-the-minister-of-health-and-mass-media-and-the-director-general-of-the-world-health-organization-in-geneva-switzerland/)
9th May 2025
##### Minister Dr. Nalinda Jayatissa elected as the President of the Sri Lanka-India Parliamentary Friendship Association
[READ MORE ](https://www.health.gov.lk/news/minister-dr-nalinda-jayatissa-elected-as-the-president-of-the-sri-lanka-india-parliamentary-friendship-association/)
7th Apr 2025
##### A comprehensive plan to digitally transform healthcare
[READ MORE ](https://www.health.gov.lk/news/a-comprehensive-plan-to-digitally-transform-healthcare/)
2nd Apr 2025
##### The Ministry of Health is fully focused on urgent measures that can be taken to control cancer in the country…
[READ MORE ](https://www.health.gov.lk/news/the-ministry-of-health-is-fully-focused-on-urgent-measures-that-can-be-taken-to-control-cancer-in-the-country/)
[ 16th Dec 2025 Mr. IWASE KIICHIRO, the head of the disaster management expert team that arrived in Sri Lanka from Japan, emphasizes that the program to provide emergency health services to the people affected by disasters in Sri Lanka was very successful. ](https://www.health.gov.lk/news/mr-iwase-kiichiro-the-head-of-the-disaster-management-expert-team-that-arrived-in-sri-lanka-from-japan-emphasizes-that-the-program-to-provide-emergency-health-services-to-the-people-affected-by-dis/)
12th Dec 2025
##### The International Conference on Emergency Ultrasound (ResUSS 2025) will commence in Kalutara under the patronage of the Minister of Health and Mass Media, Dr. Nalinda Jayatissa…
[READ MORE ](https://www.health.gov.lk/news/the-international-conference-on-emergency-ultrasound-resuss-2025-will-commence-in-kalutara-under-the-patronage-of-the-minister-of-health-and-mass-media-dr-nalinda-jayatissa/)
## Our Services
###### [Hospital Base Care ](https://www.health.gov.lk/hospital-base-care/)
###### [Public Health ](https://www.health.gov.lk/public-health-services/)
###### [Your health and wellbeing ](https://www.health.gov.lk/your-health-and-wellbeing/)
###### [Hospital Base Care ](https://www.health.gov.lk/hospital-base-care/)
###### [Public Health ](https://www.health.gov.lk/public-health-services/)
###### [Your health and wellbeing ](https://www.health.gov.lk/your-health-and-wellbeing/)
###### [Hospital Base Care ](https://www.health.gov.lk/hospital-base-care/)
###### [Public Health ](https://www.health.gov.lk/public-health-services/)
###### [Your health and wellbeing ](https://www.health.gov.lk/your-health-and-wellbeing/)
## Projects
[READ MORE PROJECT ](https://www.health.gov.lk/projects)
Health & Medical Service Improvement Project – JICA
[Read More ](https://www.health.gov.lk/sub_projects/health-medical-service-improvement-project-jica-gosl/)
Important Messages
දිට්වා සුළිකුණාටුව හේතුයෙන් �...
[DOWNLOAD ](https://www.health.gov.lk/wp-content/uploads/2025/12/Batch4636.pdf)
Date Extended - National Health Resource Symposium 2025...
[DOWNLOAD ](https://www.health.gov.lk/wp-content/uploads/2025/07/COA-NHRS-Ext29SEP20251.jpg)
World Antimicrobial Resistance Awareess Week (WAAW) - 25 18th-24th November 2025...
[DOWNLOAD ](https://www.health.gov.lk/wp-content/uploads/2025/09/02-141-2025.pdf)
[READ MORE ](https://www.health.gov.lk/important-messages/)
### Vacancies and Recruitments
##### Right to Information (RTI)
##### Fellowship/ International Training
##### Vacancies
##### Right to Information (RTI)
##### Fellowship/ International Training
##### Vacancies
##### Right to Information (RTI)
## Tenders & Procurements
Publish : 10-12-2025 
Closing : 
Procurement of Plasma Sterilizer Single door 1301, 04 Nos for Ministry
[DOWNLOAD ](https://www.health.gov.lk/wp-content/uploads/2025/12/Batch658.pdf)
Publish : 21-11-2025 
Closing : 
Procurement of End Point Security for End User Devices for Retail Outl
[DOWNLOAD ](https://www.health.gov.lk/wp-content/uploads/2025/11/ADB.pdf)
[READ MORE TENDERS ](https://www.health.gov.lk/tenders-procuments/)
## Circulars
Health Circulars
[READ MORE CIRCULARS ](http://www.previousmoh.health.gov.lk/CMS/cmsmoh1/)
Other Circulars
[READ MORE CIRCULARS ](https://www.health.gov.lk/other-circulars/)
## Press Release
03 September, 2025 
රජයේ රෝහල් 15ක් සදහා අති නවී 
[DOWNLOAD ](https://www.health.gov.lk/wp-content/uploads/2025/09/2025.09.03-%E0%B6%B1%E0%B7%80%E0%B7%93%E0%B6%B1-%E0%B6%86%E0%B7%83%E0%B7%8F%E0%B6%B0%E0%B7%92%E0%B6%AD-%E0%B6%85%E0%B6%B4%E0%B6%AF%E0%B7%8A_%E0%B6%BB%E0%B7%80%E0%B7%8A_%E0%B6%BA-%E0%B6%AF%E0%B7%8F%E0%B7%84%E0%B6%9A-%E0%B6%BA%E0%B6%B1%E0%B7%8A%E0%B6%AD%E0%B7%8A_%E0%B6%BB.pdf)
19 June, 2025 
කළුතර නාගොඩ ශික්ෂණ රෝහලේ ස 
[DOWNLOAD ](https://www.health.gov.lk/wp-content/uploads/2025/06/2025.06.19-%E0%B6%9A%E0%B7%85%E0%B7%94%E0%B6%AD%E0%B6%BB-%E0%B6%B1%E0%B7%8F%E0%B6%9C%E0%B7%9C%E0%B6%A9-%E0%B7%81%E0%B7%92%E0%B6%9A%E0%B7%8A%E0%B7%82%E0%B6%AB-%E0%B6%BB%E0%B7%9D%E0%B7%84%E0%B6%BD.pdf)
[READ MORE](https://www.health.gov.lk/gazetts-notice/)
Publications
09/01/2024
Policies for public opinion
Research
09/08/2022
Research – Funding
## More About Us
###### [Your Health & Wellbeing ](http://www.health.gov.lk/your-health-and-wellbeing/)
###### [Image Gallery ](http://www.health.gov.lk/gallery)
###### [Video Gallery ](http://www.health.gov.lk/gallery/#video-gallery)
###### [Your Health & Wellbeing ](http://www.health.gov.lk/your-health-and-wellbeing/)
###### [Image Gallery ](http://www.health.gov.lk/gallery)
###### [Video Gallery ](http://www.health.gov.lk/gallery/#video-gallery)
###### [Your Health & Wellbeing ](http://www.health.gov.lk/your-health-and-wellbeing/)
###### [Image Gallery ](http://www.health.gov.lk/gallery)
###### [Video Gallery ](http://www.health.gov.lk/gallery/#video-gallery)
Health Institutions
In Sri Lanka
[READ MORE ](https://www.health.gov.lk/health-institutions-in-sri-lanka)
SRI LANKA’S
Hospitals
Important Links
[Independent Medical Practitioners Association](http://www.impa-sl.com/)
[READ MORE ](https://www.health.gov.lk/important-links/)
## Emergency Hotline Numbers
1907
SUWASAWANA
117
PRESIDENTIAL TASK FORCE
1999
TRILINGUAL HEALTH LINE
1990
SUWASERIYA AMBULANCE
