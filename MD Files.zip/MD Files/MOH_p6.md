Source URL: https://www.health.gov.lk/your-health-and-wellbeing

[Home](https://www.health.gov.lk) / Your Health and Wellbeing 
Your Health & Wellbeing
We work with government, public health, and healthcare partners to prevent illness and enhance health. We provide guidance on the necessary health protection for Sri Lankans. Infectious disease outbreaks and environmental incidents are monitored, prepared for, detected, and responded to. We try to enhance public health by delivering evidence-based solutions to issues such as smoking, unhealthy eating, and physical inactivity.
Our educational program prepares our health staff to tackle tomorrow’s public health challenges by increasing their skills, capacity, and competencies. Our experts provide evidence and research findings to health professionals on areas such as immunization, environmental and occupational health, health promotion, infection prevention and control, and potential health emergencies. Our research influences health policy, clinical and public health practices, and laboratory sciences for the betterment of the country.
  * NCD
  * INFECTIOUS dISEASE
  * NUTRITIONS
  * ORAL HEALTH
  * DIGITAL HEALTH


